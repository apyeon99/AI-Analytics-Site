// 실행 중인 사이트(로컬 또는 Render)를 실제로 확인합니다. 실제 Claude API를 1번 호출합니다.
// 사용법: node scripts/smoke.js <사이트 주소> <접근 코드>
//   예:  node scripts/smoke.js http://localhost:3000 my-code
const [base = "http://localhost:3000", code = process.env.ACCESS_CODE] = process.argv.slice(2);
if (!code) { console.error("사용법: node scripts/smoke.js <사이트 주소> <접근 코드>"); process.exit(1); }

async function step(name, fn) {
  try { const info = await fn(); console.log("✔", name, info ? "— " + info : ""); }
  catch (e) { console.error("✘", name, "—", e.message); process.exit(1); }
}
async function post(path, body, token) {
  const res = await fetch(base + path, {
    method: "POST",
    headers: { "Content-Type": "application/json", ...(token && { Authorization: "Bearer " + token }) },
    body: JSON.stringify(body)
  });
  return { status: res.status, data: await res.json().catch(() => ({})) };
}

(async () => {
  let token;
  await step("헬스 체크 /healthz", async () => {
    const r = await fetch(base + "/healthz");
    if (!r.ok) throw new Error("HTTP " + r.status);
  });
  await step("메인 페이지", async () => {
    const html = await (await fetch(base + "/")).text();
    if (!html.includes("세종대학교 AI 상담센터")) throw new Error("페이지 내용이 예상과 다름");
  });
  await step("접근 코드 로그인", async () => {
    const r = await post("/api/login", { code });
    if (!r.data.token) throw new Error(r.data.error || "HTTP " + r.status);
    token = r.data.token;
  });
  await step("위기 메시지 안내 (모델 호출 없음)", async () => {
    const r = await post("/api/chat", { category: "학업·성적", messages: [{ role: "user", content: "죽고 싶어요" }] }, token);
    if (!r.data.crisis || !r.data.reply.includes("109")) throw new Error(JSON.stringify(r.data));
  });
  await step("개인정보 차단", async () => {
    const r = await post("/api/chat", { category: "학업·성적", messages: [{ role: "user", content: "010-1234-5678" }] }, token);
    if (r.status !== 422) throw new Error("HTTP " + r.status);
  });
  await step("Claude 실제 답변", async () => {
    const t = Date.now();
    const r = await post("/api/chat", { category: "학업·성적", messages: [{ role: "user", content: "시험이 일주일 남았는데 뭐부터 해야 할까요?" }] }, token);
    if (r.status !== 200 || r.data.source !== "ai") throw new Error(r.data.error || "HTTP " + r.status);
    return `${Date.now() - t}ms\n\n${r.data.reply}\n`;
  });
  console.log("모든 확인 통과 ✅");
})();
