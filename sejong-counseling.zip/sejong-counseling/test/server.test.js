// 실제 API 키 없이 서버 전체 흐름을 확인하는 테스트.
// 가짜 Claude API 서버를 띄우고 ANTHROPIC_BASE_URL로 연결합니다. (비용 없음)
const { test, before, after } = require("node:test");
const assert = require("node:assert/strict");
const http = require("node:http");
const path = require("node:path");
const { spawn } = require("node:child_process");

const ACCESS_CODE = "test-code";
let mock, mockPort, server, base, lastRequest, mockReply = "시험까지 남은 날짜부터 같이 정리해 볼까요?";

function listen(srv) {
  return new Promise(r => srv.listen(0, "127.0.0.1", () => r(srv.address().port)));
}
async function freePort() {
  const s = http.createServer(); const p = await listen(s); await new Promise(r => s.close(r)); return p;
}
async function post(p, body, token) {
  const headers = { "Content-Type": "application/json" };
  if (token) headers.Authorization = "Bearer " + token;
  const res = await fetch(base + p, { method: "POST", headers, body: JSON.stringify(body) });
  return { status: res.status, data: await res.json().catch(() => ({})) };
}
async function login() {
  return (await post("/api/login", { code: ACCESS_CODE })).data.token;
}

before(async () => {
  // 가짜 Claude Messages API
  mock = http.createServer((req, res) => {
    let raw = "";
    req.on("data", c => raw += c);
    req.on("end", () => {
      lastRequest = { url: req.url, headers: req.headers, body: JSON.parse(raw || "{}") };
      res.writeHead(200, { "Content-Type": "application/json" });
      res.end(JSON.stringify({
        id: "msg_test", type: "message", role: "assistant", model: lastRequest.body.model,
        content: [{ type: "text", text: mockReply }],
        stop_reason: "end_turn", stop_sequence: null,
        usage: { input_tokens: 10, output_tokens: 10 }
      }));
    });
  });
  mockPort = await listen(mock);

  const port = await freePort();
  base = `http://127.0.0.1:${port}`;
  server = spawn(process.execPath, [path.join(__dirname, "..", "server.js")], {
    env: {
      ...process.env,
      PORT: String(port),
      ANTHROPIC_API_KEY: "sk-ant-test-dummy",
      ANTHROPIC_BASE_URL: `http://127.0.0.1:${mockPort}`,
      ACCESS_CODE,
      SESSION_SECRET: "test-secret-0123456789abcdef",
      RATE_LIMIT_PER_MIN: "1000",
      DOTENV_CONFIG_PATH: "/nonexistent" // 로컬 .env를 읽지 않음
    },
    stdio: ["ignore", "pipe", "pipe"]
  });
  server.stderr.on("data", d => process.stderr.write("[server] " + d));
  for (let i = 0; i < 50; i++) {
    try { if ((await fetch(base + "/healthz")).ok) return; } catch {}
    await new Promise(r => setTimeout(r, 100));
  }
  throw new Error("서버가 시작되지 않았습니다");
});

after(() => { server && server.kill(); mock && mock.close(); });

test("메인 페이지와 safety.js가 제공된다", async () => {
  const html = await (await fetch(base + "/")).text();
  assert.match(html, /세종대학교 AI 상담센터/);
  assert.match(html, /내부 테스트용/);
  assert.match(html, /외부 AI 서비스/);
  assert.equal((await fetch(base + "/safety.js")).status, 200);
});

test("잘못된 접근 코드는 거부된다", async () => {
  const r = await post("/api/login", { code: "wrong" });
  assert.equal(r.status, 401);
});

test("토큰 없이 채팅하면 401", async () => {
  const r = await post("/api/chat", { category: "학업·성적", messages: [{ role: "user", content: "안녕" }] });
  assert.equal(r.status, 401);
});

test("위조된 토큰은 거부된다", async () => {
  const r = await post("/api/chat", { category: "학업·성적", messages: [{ role: "user", content: "안녕" }] },
    String(Date.now() + 1e9) + ".fake");
  assert.equal(r.status, 401);
});

test("정상 메시지는 Claude로 전달되고 답변이 돌아온다", async () => {
  const token = await login();
  lastRequest = null;
  const r = await post("/api/chat", {
    category: "학업·성적", mood: 4,
    messages: [
      { role: "assistant", content: "안녕하세요. 인사말입니다." }, // 앞의 assistant는 제거되어야 함
      { role: "user", content: "시험이 일주일 남았어요" }
    ]
  }, token);
  assert.equal(r.status, 200);
  assert.equal(r.data.reply, mockReply);
  assert.equal(r.data.crisis, false);
  assert.ok(lastRequest, "모델이 호출되어야 함");
  assert.equal(lastRequest.body.model, "claude-sonnet-5-5");
  const h = lastRequest.headers;
  assert.ok(h["x-api-key"] === "sk-ant-test-dummy" || h.authorization === "Bearer sk-ant-test-dummy", "API 키는 서버에서만 전송");
  assert.match(h["anthropic-beta"] || "", /server-side-fallback/);
  assert.equal(lastRequest.body.fallbacks, "default");
  assert.match(lastRequest.body.system, /학업·성적/);
  assert.match(lastRequest.body.system, /진단하지 않습니다/);
  assert.deepEqual(lastRequest.body.messages, [{ role: "user", content: "시험이 일주일 남았어요" }]);
});

test("'사람 우선' 분야는 사람 상담 권장 지시가 들어간다", async () => {
  const token = await login();
  await post("/api/chat", { category: "우울·불안", messages: [{ role: "user", content: "요즘 계속 우울해요" }] }, token);
  assert.match(lastRequest.body.system, /사람 상담 우선/);
});

test("알 수 없는 분야는 400", async () => {
  const token = await login();
  const r = await post("/api/chat", { category: "해킹", messages: [{ role: "user", content: "hi" }] }, token);
  assert.equal(r.status, 400);
});

test("개인정보가 있으면 모델을 호출하지 않는다", async () => {
  const token = await login();
  for (const text of ["010-1234-5678로 연락주세요", "학번 20231234", "test@sejong.ac.kr"]) {
    lastRequest = null;
    const r = await post("/api/chat", { category: "학업·성적", messages: [{ role: "user", content: text }] }, token);
    assert.equal(r.status, 422, text);
    assert.equal(lastRequest, null, "모델이 호출되면 안 됨: " + text);
  }
});

test("위기 메시지는 모델 없이 고정 안내를 반환한다", async () => {
  const token = await login();
  lastRequest = null;
  const r = await post("/api/chat", { category: "학업·성적", messages: [{ role: "user", content: "요즘 죽고 싶어요" }] }, token);
  assert.equal(r.status, 200);
  assert.equal(r.data.crisis, true);
  assert.equal(lastRequest, null, "모델이 호출되면 안 됨");
  for (const n of ["109", "1577-0199", "112", "119"]) assert.ok(r.data.reply.includes(n), n);
});

test("위기 이후 대화는 모델 답변과 관계없이 안내가 붙는다", async () => {
  const token = await login();
  mockReply = "괜찮아요, 천천히 이야기해 주세요."; // 번호가 없는 모델 답변
  const r = await post("/api/chat", {
    category: "학업·성적",
    messages: [
      { role: "user", content: "자해하고 싶어요" },
      { role: "assistant", content: "이야기해 줘서 고마워요..." },
      { role: "user", content: "지금 집에 있어요" }
    ]
  }, token);
  assert.equal(r.status, 200);
  assert.equal(r.data.crisis, true);
  assert.match(lastRequest.body.system, /위기 모드/);
  assert.ok(r.data.reply.startsWith(mockReply));
  for (const n of ["109", "1577-0199", "112", "119"]) assert.ok(r.data.reply.includes(n), n);
});
