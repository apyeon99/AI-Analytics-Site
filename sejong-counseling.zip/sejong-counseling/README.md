# 세종대학교 AI 상담센터 프로토타입 (내부 테스트용 · 공식 서비스 아님)

규칙 기반 학생 상담 챗봇 데모를 Claude API(`claude-sonnet-5-5`)를 쓰는 Node/Express 앱으로 바꾼 버전입니다.

```
server.js              Express 백엔드: 접근 코드, IP별 요청 제한, 개인정보·위기 필터, Claude 호출
public/index.html      UI (대화 기록과 상담 분야를 /api/chat으로 보냄)
public/safety.js       위기 키워드·개인정보 패턴·위기 안내 문구 (브라우저와 서버가 같이 씀)
test/server.test.js    자동 테스트 (가짜 Claude 서버 사용, API 키·비용 없음)
scripts/smoke.js       실행 중인 사이트 점검 (실제 Claude 1회 호출)
render.yaml            Render 배포 설정
.env.example           환경 변수 예시 (.env는 git에 올리지 않음)
```

## 안전 처리 순서 (/api/chat)
1. 접근 코드 토큰 확인, IP별 요청 제한 (기본: 분당 10회, 하루 200회)
2. 개인정보 필터: 전화번호, 8자리 학번, 주민번호, 이메일 → 422, 모델에 보내지 않음
3. 위기 키워드: 최신 메시지에서 걸리면 모델을 부르지 않고 고정된 109 / 1577-0199 / 112·119 안내를 반환
4. 대화에 위기 신호가 한 번이라도 있었으면 모델 답변 끝에 같은 안내를 항상 붙임
5. 프론트엔드도 보내기 전에 2번과 3번을 똑같이 확인함

## 로컬 실행
Node 20 이상이 필요합니다.
```bash
npm install
cp .env.example .env     # ANTHROPIC_API_KEY, ACCESS_CODE, SESSION_SECRET 입력
npm start                # http://localhost:3000
```

## 테스트
```bash
npm test                                         # 자동 테스트 (API 키 불필요)
npm run smoke -- http://localhost:3000 <접근코드>   # 실행 중인 사이트 점검 (실제 Claude 호출 1회)
```
GitHub에 올리면 `.github/workflows/test.yml`이 push마다 `npm test`를 실행합니다.

## Render 배포
1. 이 저장소를 GitHub에 올립니다.
2. Render에서 **New → Blueprint** 로 저장소를 연결하면 `render.yaml`을 읽습니다.
3. `ANTHROPIC_API_KEY`, `ACCESS_CODE`를 입력합니다. `SESSION_SECRET`은 자동 생성됩니다.
4. 배포 후 `npm run smoke -- https://<서비스>.onrender.com <접근코드>` 로 확인합니다.
