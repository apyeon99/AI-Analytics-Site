// 위기 키워드 · 개인정보 필터 · 위기 안내 문구
// 브라우저(window.Safety)와 서버(require)에서 같은 파일을 사용합니다.
(function (root, factory) {
  if (typeof module === "object" && module.exports) module.exports = factory();
  else root.Safety = factory();
})(typeof self !== "undefined" ? self : this, function () {
  const riskWords = [
    "죽고 싶", "죽고싶", "자살", "자해", "살기 싫", "살기싫", "없어지고 싶", "사라지고 싶",
    "죽어버리", "목숨", "극단적 선택", "끝내고 싶", "손목", "유서", "뛰어내리"
  ];

  const piiPatterns = [
    /\b\d{8}\b/,                          // 학번 형식(8자리)
    /01[016789][-\s]?\d{3,4}[-\s]?\d{4}/, // 휴대폰
    /\d{6}[-\s]?[1-4]\d{6}/,              // 주민번호
    /[\w.+-]+@[\w-]+\.[\w.]+/             // 이메일
  ];

  // 위기 상황에서 모델 응답과 관계없이 항상 붙는 안내
  const CRISIS_GUIDANCE =
    "📞 지금 바로 연락할 수 있는 곳 (24시간)\n" +
    "• 자살예방상담전화 109\n" +
    "• 정신건강위기상담 1577-0199\n" +
    "• 생명이 위급하면 112 · 119";

  const CRISIS_FIRST_REPLY =
    "이야기해 줘서 정말 고마워요. 그만큼 지금 많이 힘들다는 뜻이라고 생각해요.\n\n" +
    "지금 이 마음은 AI보다 사람과 바로 이야기하는 게 가장 중요해요.\n\n" +
    CRISIS_GUIDANCE + "\n\n" +
    "가능하다면 지금 곁에 있거나 연락할 수 있는 사람에게 '나 지금 많이 힘들어'라고 알려 주세요.\n\n" +
    "지금 안전한 곳에 있나요?";

  function normalize(text) {
    return String(text || "").normalize("NFC");
  }
  function isCrisis(text) {
    const t = normalize(text);
    const compact = t.replace(/\s+/g, "");
    return riskWords.some(w => t.includes(w) || compact.includes(w.replace(/\s+/g, "")));
  }
  function hasPII(text) {
    const t = normalize(text);
    return piiPatterns.some(p => p.test(t));
  }
  // 위기 대화에서는 모델이 무엇을 말했든 고정 안내를 항상 덧붙임
  function withCrisisGuidance(reply) {
    const r = String(reply || "").trim();
    return (r ? r + "\n\n" : "") + CRISIS_GUIDANCE;
  }

  return { riskWords, piiPatterns, CRISIS_GUIDANCE, CRISIS_FIRST_REPLY, isCrisis, hasPII, withCrisisGuidance };
});
